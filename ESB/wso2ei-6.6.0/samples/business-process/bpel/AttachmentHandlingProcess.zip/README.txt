This sample process have an input which accepts an attachment. So it can be extended for testing MTOM handling by BPEL component.

Also it has the functionality of creating human task/notification defined in http://svn.wso2.org/repos/wso2/carbon/platform/trunk/products/bps/modules/samples/product/src/main/resources/humantask/ClaimsApprovalTask/.

